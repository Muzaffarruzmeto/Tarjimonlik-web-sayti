document.getElementById('translateButton').addEventListener('click', function() {
    var textToTranslate = document.getElementById('content').innerText;
    translateText(textToTranslate);
  });
  
  function translateText(text) {
    // Google Tarjimon API-dan foydalanish uchun PHP-ga so'rov yuborish
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "translate.php?text=" + encodeURIComponent(text), true);
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
        var translatedText = JSON.parse(xhr.responseText);
        document.getElementById('translatedText').innerText = translatedText;
      }
    };
    xhr.send();
  }