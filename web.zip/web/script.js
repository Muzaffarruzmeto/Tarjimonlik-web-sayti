// Form submit hodisasida AJAX so'rovni yuborish
document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault(); // Bunday qilish sababi sahifani qayta yuklamaslik
    
    var formData = new FormData(this);
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'translate.php', true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            document.getElementById('translation-result').textContent = xhr.responseText;
        }
    };
    xhr.send(formData);
});