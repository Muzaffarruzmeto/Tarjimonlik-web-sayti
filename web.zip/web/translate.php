<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $text = $_POST["text"];
    
    // Google Tarjimon API-ni chaqirish uchun kerakli kodlar
    // API-ni chaqirib, tarjima natijasini $translation o'zgaruvchiga saqlash
    
    echo $translation; // Tarjima natijasini ko'rsatish uchun
}
?>
